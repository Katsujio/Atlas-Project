
# Cross-Asset Portfolio Workspace (Stocks + Real Estate)

This workspace bootstraps a **FastAPI** backend and a placeholder **React + Vite** frontend.
It includes an adapter for **RentCast** to fetch property details, rent estimates, and comps.

## How to use with VS Code + ChatGPT Codex plugin
1. Open `portfolio-workspace.code-workspace` in VS Code.
2. In the **Terminal**, run the backend setup:
   ```bash
   cd backend
   python -m venv .venv
   source .venv/bin/activate  # Windows: .venv\Scripts\activate
   pip install -r requirements.txt
   cp .env.example .env  # add your RENTCAST_API_KEY
   uvicorn app.main:app --reload --port 8000
   ```
3. In a new terminal, create the frontend (Vite) via the included task:
   ```bash
   cd frontend
   npm create vite@latest . -- --template react
   npm i
   npm run dev
   ```
4. Point the Codex plugin at this workspace. Use the `/backend/app` and `/frontend/src` TODOs and the issue list below to drive implementation.

## RentCast Integration
- Files: `backend/app/providers/rental_base.py`, `backend/app/providers/rentcast.py`, `backend/app/routers/rentcast.py`
- Add your `RENTCAST_API_KEY` to `backend/.env`

## API Quick Start
- Health: `GET http://localhost:8000/health`
- RentCast preview: `GET http://localhost:8000/integrations/rentcast/preview?address=123 Main St, City, ST`

## Project Structure
```
backend/
  app/
    main.py
    db.py
    models/
      __init__.py
    providers/
      rental_base.py
      rentcast.py
    routers/
      rentcast.py
      auth.py        # TODO
      portfolios.py  # TODO
      stocks.py      # TODO
      properties.py  # TODO
      dashboard.py   # TODO
    schemas.py
  requirements.txt
  .env.example
frontend/
  (run Vite creation task to scaffold React app)
scripts/
  bootstrap_frontend.sh
.vscode/ (launch/tasks/settings for subfolder usage)
portfolio-workspace.code-workspace (multi-root workspace)
```

## Implementation TODOs (handy for Codex)
- [ ] Auth: JWT access/refresh, password hashing, user CRUD
- [ ] Portfolios: CRUD, attach holdings/properties
- [ ] Stocks: holdings CRUD, price fetch + cache, allocation
- [ ] Properties: CRUD, valuation method, mortgage schedule, rent/expenses
- [ ] Dashboard: net worth, timeseries, allocation, cash-flow summary
- [ ] Reports: CSV/PDF monthly performance, property cash-flow
- [ ] Frontend: forms (zod/react-hook-form), lists, dashboard charts, insights drawer
- [ ] Testing: pytest unit (math, mapping), React Testing Library for key components
- [ ] CI: lint, type-check, run unit tests

## Notes
- Keep provider keys on the server side only.
- Respect RentCast rate limits; TTL caching recommended.
- Swap providers by implementing the `IRentalDataProvider` interface.
