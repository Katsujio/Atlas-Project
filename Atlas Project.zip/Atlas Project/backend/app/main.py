
import os
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.routers import rentcast as rentcast_router
from app.db import engine
from app.models import Base

app = FastAPI(title="Cross-Asset Portfolio API", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=os.getenv("CORS_ORIGINS", "*").split(","),
    allow_methods=["*"],
    allow_headers=["*"],
    allow_credentials=True,
)

# Create tables automatically for dev (use Alembic for prod)
Base.metadata.create_all(bind=engine)

@app.get("/health")
def health(): return {"status":"ok"}

# Routers
app.include_router(rentcast_router.router)
# TODO: include other routers when implemented
