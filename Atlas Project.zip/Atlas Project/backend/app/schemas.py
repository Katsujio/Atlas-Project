
from pydantic import BaseModel

class RentCastPreview(BaseModel):
    details: dict
    estimate: dict
    comps: list
