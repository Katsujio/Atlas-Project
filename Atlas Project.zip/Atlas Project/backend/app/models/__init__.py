
from sqlalchemy.orm import declarative_base, relationship, Mapped, mapped_column
from sqlalchemy import String, Integer, Float, ForeignKey, Date, DateTime, func

Base = declarative_base()

class User(Base):
    __tablename__="users"
    id: Mapped[int] = mapped_column(primary_key=True)
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(String(255))
    created_at: Mapped[DateTime] = mapped_column(server_default=func.now())

class Portfolio(Base):
    __tablename__="portfolios"
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"))
    name: Mapped[str] = mapped_column(String(120), default="My Portfolio")

class Property(Base):
    __tablename__="properties"
    id: Mapped[int] = mapped_column(primary_key=True)
    portfolio_id: Mapped[int] = mapped_column(ForeignKey("portfolios.id", ondelete="CASCADE"))
    address: Mapped[str] = mapped_column(String(255))
    city: Mapped[str] = mapped_column(String(120))
    state: Mapped[str] = mapped_column(String(8))
    zip: Mapped[str] = mapped_column(String(16))
    purchase_price: Mapped[float] = mapped_column(Float, default=0.0)
    purchase_date: Mapped[Date] = mapped_column(nullable=True)
    valuation_method: Mapped[str] = mapped_column(String(32), default="manual")
    last_valuation: Mapped[float] = mapped_column(Float, default=0.0)
    last_valuation_at: Mapped[DateTime] = mapped_column(nullable=True)
    # RentCast enrichments
    bedrooms: Mapped[float] = mapped_column(Float, default=0.0)
    bathrooms: Mapped[float] = mapped_column(Float, default=0.0)
    living_area_sqft: Mapped[float] = mapped_column(Float, default=0.0)
    year_built: Mapped[int] = mapped_column(Integer, nullable=True)
    rc_last_checked_at: Mapped[DateTime] = mapped_column(nullable=True)
    rc_confidence: Mapped[float] = mapped_column(Float, default=0.0)
    rc_source_id: Mapped[str] = mapped_column(String(64), nullable=True)

class RentEstimate(Base):
    __tablename__="rent_estimates"
    id: Mapped[int] = mapped_column(primary_key=True)
    property_id: Mapped[int] = mapped_column(ForeignKey("properties.id", ondelete="CASCADE"))
    estimate: Mapped[float] = mapped_column(Float)
    low: Mapped[float] = mapped_column(Float)
    high: Mapped[float] = mapped_column(Float)
    as_of: Mapped[DateTime] = mapped_column(server_default=func.now())
    provider: Mapped[str] = mapped_column(String(32), default="rentcast")

class RentComp(Base):
    __tablename__="rent_comps"
    id: Mapped[int] = mapped_column(primary_key=True)
    property_id: Mapped[int] = mapped_column(ForeignKey("properties.id", ondelete="CASCADE"))
    address: Mapped[str] = mapped_column(String(255))
    distance_mi: Mapped[float] = mapped_column(Float, default=0.0)
    monthly_rent: Mapped[float] = mapped_column(Float, default=0.0)
    bed: Mapped[float] = mapped_column(Float, default=0.0)
    bath: Mapped[float] = mapped_column(Float, default=0.0)
    sqft: Mapped[float] = mapped_column(Float, default=0.0)
    days_on_market: Mapped[int] = mapped_column(Integer, default=0)
    as_of: Mapped[DateTime] = mapped_column(server_default=func.now())
    provider: Mapped[str] = mapped_column(String(32), default="rentcast")
