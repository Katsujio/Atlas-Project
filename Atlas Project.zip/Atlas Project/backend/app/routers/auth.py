from fastapi import APIRouter
router = APIRouter(prefix='/auth', tags=['auth'])
# TODO: implement register/login/refresh
