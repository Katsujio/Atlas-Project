from fastapi import APIRouter
router = APIRouter(prefix='/stocks', tags=['stocks'])
# TODO: implement holdings + prices
