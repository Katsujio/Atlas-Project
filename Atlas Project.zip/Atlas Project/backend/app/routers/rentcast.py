
from fastapi import APIRouter, HTTPException
from app.providers.rentcast import RentCastProvider

router = APIRouter(prefix="/integrations/rentcast", tags=["integrations"])

@router.get("/preview")
def preview_rent_data(address:str):
    provider = RentCastProvider()
    try:
        details = provider.get_property_details(address)
        estimate = provider.get_rent_estimate(address)
        comps = provider.get_rent_comps(address, limit=8)
        return {"details": details, "estimate": estimate, "comps": comps}
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"RentCast error: {e}")
