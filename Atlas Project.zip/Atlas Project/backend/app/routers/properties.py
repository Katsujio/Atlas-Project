from fastapi import APIRouter
router = APIRouter(prefix='/properties', tags=['properties'])
# TODO: implement CRUD + valuation/mortgage/rent/expenses
