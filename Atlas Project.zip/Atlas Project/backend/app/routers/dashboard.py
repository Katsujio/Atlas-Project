from fastapi import APIRouter
router = APIRouter(prefix='/dashboard', tags=['dashboard'])
# TODO: implement net-worth, timeseries, allocation
