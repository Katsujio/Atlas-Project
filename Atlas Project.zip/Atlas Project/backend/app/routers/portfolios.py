from fastapi import APIRouter
router = APIRouter(prefix='/portfolios', tags=['portfolios'])
# TODO: implement CRUD
